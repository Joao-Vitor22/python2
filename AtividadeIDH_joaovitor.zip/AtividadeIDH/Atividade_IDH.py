from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


BASE = Path(__file__).parent
ARQUIVO = BASE / "Tabela4.csv"


def carregar_dados(caminho):
    tabela = pd.read_csv(
        caminho,
        sep=";",
        decimal=",",
        encoding="latin1",
        skiprows=1,
    )
    tabela = tabela.dropna(axis=1, how="all")
    tabela.columns = [str(nome).strip() for nome in tabela.columns]
    return tabela


def preparar_numeros(tabela):
    anos = [nome for nome in tabela.columns if nome.isdigit()]
    tabela[anos] = tabela[anos].apply(pd.to_numeric, errors="coerce")
    return anos


def mostrar_resumo(tabela, anos):
    inicio, fim = anos[0], anos[-1]
    tabela["mudanca"] = tabela[fim] - tabela[inicio]

    print(f"\nDados disponíveis de {inicio} a {fim}.")
    print(f"Quantidade de estados/DF: {tabela.shape[0]}")

    ranking = tabela.loc[:, ["Sigla", "Estado", fim]].copy()
    ranking = ranking.sort_values(fim, ascending=False)
    print(f"\nRanking do IDH em {fim}:")
    print(ranking.to_string(index=False))

    pos = tabela["mudanca"].idxmax()
    estado = tabela.loc[pos]
    print(f"\nMaior aumento no período: {estado['Estado']} ({estado['Sigla']})")
    print(f"IDH inicial: {estado[inicio]:.3f}")
    print(f"IDH final:   {estado[fim]:.3f}")
    print(f"Diferença:   {estado['mudanca']:.3f}")

    reducoes = tabela[tabela["mudanca"] < 0][
        ["Sigla", "Estado", inicio, fim, "mudanca"]
    ]
    if len(reducoes) == 0:
        print("\nNão foram encontradas reduções entre os anos inicial e final.")
    else:
        print("\nUnidades com redução:")
        print(reducoes.to_string(index=False))


def transformar_em_serie(tabela, anos):
    colunas_fixas = [c for c in tabela.columns if c not in anos]
    serie = tabela.melt(
        id_vars=colunas_fixas,
        value_vars=anos,
        var_name="Ano",
        value_name="IDH",
    )
    serie["Ano"] = serie["Ano"].astype(int)
    return serie.dropna(subset=["IDH"])


def grafico_minas(serie):
    dados_mg = serie[serie["Sigla"] == "MG"].sort_values("Ano")

    plt.figure(figsize=(9, 5))
    plt.plot(dados_mg["Ano"], dados_mg["IDH"], marker="o")
    plt.title("IDH de Minas Gerais ao longo dos anos")
    plt.xlabel("Ano")
    plt.ylabel("IDH")
    plt.ylim(0.3, 0.9)
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    plt.show()


def grafico_ufs(serie):
    fig, ax = plt.subplots(figsize=(12, 7))

    for sigla, dados_uf in serie.groupby("Sigla"):
        dados_uf = dados_uf.sort_values("Ano")
        ax.plot(dados_uf["Ano"], dados_uf["IDH"], label=sigla, linewidth=1.2)

    ax.set_title("Variação histórica do IDH por UF")
    ax.set_xlabel("Ano")
    ax.set_ylabel("IDH")
    ax.set_ylim(0.3, 0.9)
    ax.legend(ncol=3, bbox_to_anchor=(1.02, 1), loc="upper left")
    fig.tight_layout()
    plt.show()


def main():
    dados = carregar_dados(ARQUIVO)
    anos = preparar_numeros(dados)

    mostrar_resumo(dados, anos)
    historico = transformar_em_serie(dados, anos)

    grafico_minas(historico)
    grafico_ufs(historico)


if __name__ == "__main__":
    main()
